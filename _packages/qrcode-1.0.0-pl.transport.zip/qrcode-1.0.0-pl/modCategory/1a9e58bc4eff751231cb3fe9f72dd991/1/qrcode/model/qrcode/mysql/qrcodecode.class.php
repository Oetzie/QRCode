<?php

/**
 * QR Code
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/qrcodecode.class.php';

class QRCodeCode_mysql extends QRCodeCode
{
}
