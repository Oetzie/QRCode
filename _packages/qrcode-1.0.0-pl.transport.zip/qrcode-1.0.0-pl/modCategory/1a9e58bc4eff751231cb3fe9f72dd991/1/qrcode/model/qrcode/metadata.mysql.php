<?php

/**
 * QR Code
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'QRCodeCode'
    ]
];
